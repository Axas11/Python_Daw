from Videojuego import Videojuego
from Usuario import Usuario
from datos import get_juegos, get_usuarios
from datetime import datetime
from funcs import buscar_usuario, filtro_edad, menu, print_menu

menu()
